## Hangman Game
[![Hits](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Fxdvrx1%2Fhangman-game&count_bg=%2379C83D&title_bg=%23555555&icon=&icon_color=%23E7E7E7&title=HANGMAN+GAME+HITS&edge_flat=false)](https://hits.seeyoufarm.com)

hangman game from Vanilla Web Projects

click the link to run the program:
<https://jdevstatic.github.io/hangman-game/>

I simply used the GitHub Pages to deploy the program!
